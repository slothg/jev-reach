import type { TypeSafeClient } from '@typesafe-ai/sdk';
export const VISION_MODEL: string;
export function readImage(path: string): Promise<Buffer>;
export function imageSize(data: Uint8Array): { width: number; height: number };
export function inspectImage(input: { data: Uint8Array; question?: string; options?: Record<string, string>; target?: string;
  minPresence?: number; minConfidence?: number }, client?: TypeSafeClient, signal?: AbortSignal): Promise<{
    model: string; usage: { input_tokens: number | null; output_tokens: number | null };
    image: { width: number; height: number }; answer?: any;
    localization?: { presence: number; confidence: number | null; accepted: boolean;
      box: { left: number; top: number; right: number; bottom: number } | null;
      pixels: { left: number; top: number; right: number; bottom: number } | null };
  }>;
